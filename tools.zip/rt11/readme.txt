Copy all files under this folder into BK3DA or BK3DE.

https://emulator.pdp-11.org.ru/RT-11/

